<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$page_title = 'Settings - Wrap My Kitchen';

// Handle settings updates
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_profile'])) {
        $full_name = trim($_POST['full_name']);
        $username = trim($_POST['username']);
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        try {
            // Get current user data
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch();
            
            if (!$user) {
                throw new Exception("User not found");
            }
            
            // Check if we're updating password
            if (!empty($new_password)) {
                if (empty($current_password) || !password_verify($current_password, $user['password'])) {
                    throw new Exception("Current password is incorrect");
                }
                if ($new_password !== $confirm_password) {
                    throw new Exception("New passwords do not match");
                }
                if (strlen($new_password) < 6) {
                    throw new Exception("New password must be at least 6 characters long");
                }
                
                // Update with new password
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET full_name = ?, username = ?, password = ? WHERE id = ?");
                $stmt->execute([$full_name, $username, $hashed_password, $_SESSION['user_id']]);
            } else {
                // Update without changing password
                $stmt = $pdo->prepare("UPDATE users SET full_name = ?, username = ? WHERE id = ?");
                $stmt->execute([$full_name, $username, $_SESSION['user_id']]);
            }
            
            // Update session data
            $_SESSION['full_name'] = $full_name;
            $_SESSION['username'] = $username;
            
            $success_message = "Profile updated successfully!";
            
        } catch (Exception $e) {
            $error_message = $e->getMessage();
        }
    }
}

// Get current user data
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $current_user = $stmt->fetch();
} catch (PDOException $e) {
    $error_message = "Error fetching user data: " . $e->getMessage();
}

// Get all users (for admin view)
try {
    $stmt = $pdo->query("SELECT id, username, full_name, created_at FROM users ORDER BY full_name");
    $all_users = $stmt->fetchAll();
} catch (PDOException $e) {
    $all_users = [];
}

// Get system statistics
try {
    // Total leads
    $stmt = $pdo->query("SELECT COUNT(*) as total_leads FROM leads");
    $total_leads = $stmt->fetch()['total_leads'];
    
    // Leads this month
    $stmt = $pdo->query("SELECT COUNT(*) as month_leads FROM leads WHERE MONTH(created_at) = MONTH(CURRENT_DATE) AND YEAR(created_at) = YEAR(CURRENT_DATE)");
    $month_leads = $stmt->fetch()['month_leads'];
    
    // Total sold
    $stmt = $pdo->query("SELECT COUNT(*) as sold_leads FROM leads WHERE remarks = 'Sold'");
    $sold_leads = $stmt->fetch()['sold_leads'];
    
    // Total revenue
    $stmt = $pdo->query("SELECT COALESCE(SUM(project_amount), 0) as total_revenue FROM leads WHERE remarks = 'Sold'");
    $total_revenue = $stmt->fetch()['total_revenue'];
    
} catch (PDOException $e) {
    $total_leads = $month_leads = $sold_leads = $total_revenue = 0;
}

include 'includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0">
        <i class="fas fa-cog text-primary me-2"></i>
        Settings
    </h1>
</div>

<?php if (isset($success_message)): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i>
    <?php echo $success_message; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if (isset($error_message)): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i>
    <?php echo $error_message; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row">
    <!-- Profile Settings -->
    <div class="col-lg-8">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-user me-2"></i>
                    Profile Settings
                </h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="full_name" class="form-label">Full Name</label>
                                <input type="text" class="form-control" id="full_name" name="full_name" 
                                       value="<?php echo htmlspecialchars($current_user['full_name']); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" 
                                       value="<?php echo htmlspecialchars($current_user['username']); ?>" required>
                            </div>
                        </div>
                    </div>
                    
                    <hr>
                    <h6 class="mb-3">Change Password <small class="text-muted">(leave blank to keep current)</small></h6>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="current_password" class="form-label">Current Password</label>
                                <input type="password" class="form-control" id="current_password" name="current_password">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="new_password" class="form-label">New Password</label>
                                <input type="password" class="form-control" id="new_password" name="new_password">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">Confirm New Password</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-between">
                        <small class="text-muted">Account created: <?php echo date('M j, Y', strtotime($current_user['created_at'])); ?></small>
                        <button type="submit" name="update_profile" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Update Profile
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Team Members -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-users me-2"></i>
                    Team Members
                </h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Member Since</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($all_users as $user): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($user['full_name']); ?></strong>
                                    <?php if ($user['id'] == $_SESSION['user_id']): ?>
                                        <span class="badge bg-primary ms-2">You</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo date('M j, Y', strtotime($user['created_at'])); ?></td>
                                <td>
                                    <span class="badge bg-success">Active</span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- System Statistics -->
    <div class="col-lg-4">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-pie me-2"></i>
                    System Statistics
                </h5>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-6">
                        <div class="p-3">
                            <h3 class="text-primary mb-1"><?php echo number_format($total_leads); ?></h3>
                            <small class="text-muted">Total Leads</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="p-3">
                            <h3 class="text-success mb-1"><?php echo number_format($month_leads); ?></h3>
                            <small class="text-muted">This Month</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="p-3">
                            <h3 class="text-info mb-1"><?php echo number_format($sold_leads); ?></h3>
                            <small class="text-muted">Sold Leads</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="p-3">
                            <h3 class="text-warning mb-1">$<?php echo number_format($total_revenue, 0); ?></h3>
                            <small class="text-muted">Total Revenue</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- System Information -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-info-circle me-2"></i>
                    System Information
                </h5>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <strong>Company:</strong><br>
                    <span class="text-muted">Wrap My Kitchen</span>
                </div>
                <div class="mb-3">
                    <strong>Designed & Developed By:</strong><br>
                    <span class="text-muted">Koen Studio</span>
                </div>
                <div class="mb-3">
                    <strong>Database:</strong><br>
                    <span class="text-muted">MySQL</span>
                </div>
                <div class="mb-3">
                    <strong>Current User:</strong><br>
                    <span class="text-muted"><?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                </div>
                <div class="mb-0">
                    <strong>Last Login:</strong><br>
                    <span class="text-muted"><?php echo date('M j, Y g:i A'); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>