<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$page_title = 'Follow-Ups - Wrap My Kitchen';

// Function to get lead origin CSS class
function getLeadOriginClass($origin) {
    $origin_lower = strtolower(trim($origin));
    switch ($origin_lower) {
        case 'facebook':
            return 'lead-origin-facebook';
        case 'google':
            return 'lead-origin-google';
        case 'google text':
        case 'googletext':
            return 'lead-origin-googletext';
        case 'referral':
            return 'lead-origin-referral';
        case 'website':
            return 'lead-origin-website';
        case 'instagram':
            return 'lead-origin-instagram';
        case 'tiktok':
            return 'lead-origin-tiktok';
        case 'youtube':
            return 'lead-origin-youtube';
        case 'linkedin':
            return 'lead-origin-linkedin';
        case 'twitter':
            return 'lead-origin-twitter';
        case 'email':
            return 'lead-origin-email';
        case 'phone':
            return 'lead-origin-phone';
        case 'walk-in':
        case 'walkin':
            return 'lead-origin-walkin';
        case 'trade show':
        case 'tradeshow':
            return 'lead-origin-tradeshow';
        case 'whatsapp':
            return 'lead-origin-whatsapp';
        default:
            return 'lead-origin-other';
    }
}

// Handle follow-up date updates
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_followup'])) {
    $lead_id = $_POST['lead_id'];
    $new_followup_date = $_POST['next_followup_date'];
    
    try {
        $stmt = $pdo->prepare("UPDATE leads SET next_followup_date = ? WHERE id = ?");
        $stmt->execute([$new_followup_date, $lead_id]);
        $success_message = "Follow-up date updated successfully!";
    } catch (PDOException $e) {
        $error_message = "Error updating follow-up date: " . $e->getMessage();
    }
}

// Handle lead updates
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_lead'])) {
    $lead_id = $_POST['lead_id'];
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $remarks = $_POST['remarks'];
    $assigned_to = $_POST['assigned_to'];
    $notes = trim($_POST['notes']);
    $project_amount = !empty($_POST['project_amount']) ? floatval($_POST['project_amount']) : 0;
    
    try {
        $stmt = $pdo->prepare("
            UPDATE leads SET 
                name = ?, phone = ?, email = ?, remarks = ?, 
                assigned_to = ?, notes = ?, project_amount = ?
            WHERE id = ?
        ");
        $stmt->execute([$name, $phone, $email, $remarks, $assigned_to, $notes, $project_amount, $lead_id]);
        $success_message = "Lead updated successfully!";
    } catch (PDOException $e) {
        $error_message = "Error updating lead: " . $e->getMessage();
    }
}

// Get leads that need follow-up (overdue and due today)
$today = date('Y-m-d');
$sql = "
    SELECT * FROM leads 
    WHERE next_followup_date <= ? 
    AND remarks NOT IN ('Sold', 'Not Service Area', 'Not Interested', 'Not Compatible')
    ORDER BY next_followup_date ASC, created_at DESC
";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$today]);
    $followup_leads = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_message = "Error fetching follow-up leads: " . $e->getMessage();
    $followup_leads = [];
}

// Get upcoming follow-ups (next 7 days)
$next_week = date('Y-m-d', strtotime('+7 days'));
$upcoming_sql = "
    SELECT * FROM leads 
    WHERE next_followup_date > ? AND next_followup_date <= ?
    AND remarks NOT IN ('Sold', 'Not Service Area', 'Not Interested', 'Not Compatible')
    ORDER BY next_followup_date ASC
";

try {
    $stmt = $pdo->prepare($upcoming_sql);
    $stmt->execute([$today, $next_week]);
    $upcoming_leads = $stmt->fetchAll();
} catch (PDOException $e) {
    $upcoming_leads = [];
}

// Get all users for the assigned_to dropdown
try {
    $stmt = $pdo->prepare("SELECT id, full_name, username FROM users ORDER BY full_name");
    $stmt->execute();
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    $users = [];
}

include 'includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0">
        <i class="fas fa-calendar-check text-primary me-2"></i>
        Follow-Up Management
    </h1>
</div>

<?php if (isset($success_message)): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i>
    <?php echo $success_message; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if (isset($error_message)): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i>
    <?php echo $error_message; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card bg-danger text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Overdue Follow-Ups</h5>
                        <h2 class="mb-0"><?php echo count(array_filter($followup_leads, function($lead) { return $lead['next_followup_date'] < date('Y-m-d'); })); ?></h2>
                    </div>
                    <div class="fs-1 opacity-75">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Due Today</h5>
                        <h2 class="mb-0"><?php echo count(array_filter($followup_leads, function($lead) { return $lead['next_followup_date'] == date('Y-m-d'); })); ?></h2>
                    </div>
                    <div class="fs-1 opacity-75">
                        <i class="fas fa-calendar-day"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Next 7 Days</h5>
                        <h2 class="mb-0"><?php echo count($upcoming_leads); ?></h2>
                    </div>
                    <div class="fs-1 opacity-75">
                        <i class="fas fa-calendar-week"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Priority Follow-Ups -->
<?php if (!empty($followup_leads)): ?>
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-fire text-danger me-2"></i>
            Priority Follow-Ups (Overdue & Due Today)
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Lead Origin</th>
                        <th>Follow-Up Date</th>
                        <th>Status</th>
                        <th>Assigned To</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($followup_leads as $lead): ?>
                    <?php 
                        $is_overdue = $lead['next_followup_date'] < date('Y-m-d');
                        $is_due_today = $lead['next_followup_date'] == date('Y-m-d');
                    ?>
                    <tr class="<?php echo $is_overdue ? 'table-danger' : ($is_due_today ? 'table-warning' : ''); ?>">
                        <td>
                            <strong><?php echo htmlspecialchars($lead['name']); ?></strong>
                            <?php if ($is_overdue): ?>
                                <span class="badge bg-danger ms-2">OVERDUE</span>
                            <?php elseif ($is_due_today): ?>
                                <span class="badge bg-warning">DUE TODAY</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div><?php echo htmlspecialchars($lead['phone']); ?></div>
                            <small class="text-muted"><?php echo htmlspecialchars($lead['email']); ?></small>
                        </td>
                        <td>
                            <span class="badge <?php echo getLeadOriginClass($lead['lead_origin']); ?>"><?php echo htmlspecialchars($lead['lead_origin']); ?></span>
                        </td>
                        <td>
                            <div class="d-flex align-items-center">
                                <span class="me-2"><?php echo date('M j, Y', strtotime($lead['next_followup_date'])); ?></span>
                                <?php if ($is_overdue): ?>
                                    <small class="text-danger">(<?php echo abs((strtotime(date('Y-m-d')) - strtotime($lead['next_followup_date'])) / 86400); ?> days overdue)</small>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <?php if ($lead['remarks']): ?>
                                <span class="badge bg-secondary"><?php echo htmlspecialchars($lead['remarks']); ?></span>
                            <?php else: ?>
                                <span class="badge bg-light text-dark">New</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($lead['assigned_to']); ?></td>
                        <td>
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#updateFollowupModal<?php echo $lead['id']; ?>">
                                    <i class="fas fa-calendar-alt"></i>
                                </button>
                                <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#editLeadModal<?php echo $lead['id']; ?>">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Upcoming Follow-Ups -->
<?php if (!empty($upcoming_leads)): ?>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-calendar-week text-info me-2"></i>
            Upcoming Follow-Ups (Next 7 Days)
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Lead Origin</th>
                        <th>Follow-Up Date</th>
                        <th>Assigned To</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($upcoming_leads as $lead): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($lead['name']); ?></strong></td>
                        <td>
                            <div><?php echo htmlspecialchars($lead['phone']); ?></div>
                            <small class="text-muted"><?php echo htmlspecialchars($lead['email']); ?></small>
                        </td>
                        <td>
                            <span class="badge <?php echo getLeadOriginClass($lead['lead_origin']); ?>"><?php echo htmlspecialchars($lead['lead_origin']); ?></span>
                        </td>
                        <td><?php echo date('M j, Y', strtotime($lead['next_followup_date'])); ?></td>
                        <td><?php echo htmlspecialchars($lead['assigned_to']); ?></td>
                        <td>
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#updateFollowupModal<?php echo $lead['id']; ?>">
                                    <i class="fas fa-calendar-alt"></i>
                                </button>
                                <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#editLeadModal<?php echo $lead['id']; ?>">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Update Follow-up Modals -->
<?php foreach (array_merge($followup_leads, $upcoming_leads) as $lead): ?>
<div class="modal fade" id="updateFollowupModal<?php echo $lead['id']; ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title">Update Follow-up Date</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Lead:</strong> <?php echo htmlspecialchars($lead['name']); ?></p>
                    <p><strong>Current Follow-up Date:</strong> <?php echo date('M j, Y', strtotime($lead['next_followup_date'])); ?></p>
                    
                    <div class="mb-3">
                        <label for="next_followup_date<?php echo $lead['id']; ?>" class="form-label">New Follow-up Date</label>
                        <input type="date" class="form-control" id="next_followup_date<?php echo $lead['id']; ?>" name="next_followup_date" 
                               value="<?php echo $lead['next_followup_date']; ?>" required>
                    </div>
                    
                    <input type="hidden" name="lead_id" value="<?php echo $lead['id']; ?>">
                    <input type="hidden" name="update_followup" value="1">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Follow-up Date</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<!-- Edit Lead Modals -->
<?php foreach (array_merge($followup_leads, $upcoming_leads) as $lead): ?>
<div class="modal fade" id="editLeadModal<?php echo $lead['id']; ?>" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Lead</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="update_lead" value="1">
                    <input type="hidden" name="lead_id" value="<?php echo $lead['id']; ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name<?php echo $lead['id']; ?>" class="form-label">Name *</label>
                            <input type="text" class="form-control" name="name" id="name<?php echo $lead['id']; ?>" value="<?php echo htmlspecialchars($lead['name']); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="phone<?php echo $lead['id']; ?>" class="form-label">Phone *</label>
                            <input type="tel" class="form-control" name="phone" id="phone<?php echo $lead['id']; ?>" value="<?php echo htmlspecialchars($lead['phone']); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="email<?php echo $lead['id']; ?>" class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" id="email<?php echo $lead['id']; ?>" value="<?php echo htmlspecialchars($lead['email']); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="remarks<?php echo $lead['id']; ?>" class="form-label">Status *</label>
                            <select class="form-select" name="remarks" id="remarks<?php echo $lead['id']; ?>" required>
                                <option value="New" <?php echo $lead['remarks'] == 'New' ? 'selected' : ''; ?>>New</option>
                                <option value="Won" <?php echo $lead['remarks'] == 'Sold' ? 'selected' : ''; ?>>Sold</option>
                                <option value="Lost" <?php echo $lead['remarks'] == 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
                                <option value="Not Service Area" <?php echo $lead['remarks'] == 'Not Service Area' ? 'selected' : ''; ?>>Not Service Area</option>
                                <option value="Not Interested" <?php echo $lead['remarks'] == 'Not Interested' ? 'selected' : ''; ?>>Not Interested</option>
                                <option value="Not Compatible" <?php echo $lead['remarks'] == 'Not Compatible' ? 'selected' : ''; ?>>Not Compatible</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="assigned_to<?php echo $lead['id']; ?>" class="form-label">Assigned To</label>
                            <select class="form-select" name="assigned_to" id="assigned_to<?php echo $lead['id']; ?>">
                                <option value="">-- Select User --</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo htmlspecialchars($user['full_name']); ?>" 
                                            <?php echo $lead['assigned_to'] == $user['full_name'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($user['full_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="project_amount<?php echo $lead['id']; ?>" class="form-label">Project Amount</label>
                            <input type="number" class="form-control" name="project_amount" id="project_amount<?php echo $lead['id']; ?>" value="<?php echo $lead['project_amount']; ?>" step="0.01" min="0">
                        </div>
                        <div class="col-12 mb-3">
                            <label for="notes<?php echo $lead['id']; ?>" class="form-label">Notes</label>
                            <textarea class="form-control" name="notes" id="notes<?php echo $lead['id']; ?>" rows="3"><?php echo htmlspecialchars($lead['notes']); ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Update Lead</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<?php if (empty($followup_leads) && empty($upcoming_leads)): ?>
<div class="text-center py-5">
    <i class="fas fa-calendar-check display-1 text-muted mb-3"></i>
    <h3>All Caught Up!</h3>
    <p class="text-muted">No follow-ups needed at this time. Great job staying on top of your leads!</p>
    <a href="leads.php" class="btn btn-primary">View All Leads</a>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>