<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

// Set JSON header
header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$email = $input['email'] ?? '';
$phone = $input['phone'] ?? '';

if (empty($email) && empty($phone)) {
    echo json_encode(['found' => false]);
    exit;
}

try {
    $sql = "SELECT * FROM leads WHERE ";
    $params = [];
    $conditions = [];
    
    if (!empty($email)) {
        $conditions[] = "email = ?";
        $params[] = trim($email);
    }
    
    if (!empty($phone)) {
        $conditions[] = "phone = ?";
        $params[] = trim($phone);
    }
    
    $sql .= implode(' OR ', $conditions) . " ORDER BY created_at DESC LIMIT 1";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $existing_lead = $stmt->fetch();
    
    if ($existing_lead) {
        echo json_encode([
            'found' => true,
            'lead' => [
                'id' => $existing_lead['id'],
                'name' => $existing_lead['name'],
                'phone' => $existing_lead['phone'],
                'email' => $existing_lead['email'],
                'assigned_to' => $existing_lead['assigned_to'],
                'project_amount' => $existing_lead['project_amount'],
                'notes' => $existing_lead['notes'],
                'date_created' => $existing_lead['date_created'],
                'lead_origin' => $existing_lead['lead_origin'],
                'remarks' => $existing_lead['remarks']
            ]
        ]);
    } else {
        echo json_encode(['found' => false]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
