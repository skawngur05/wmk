<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$page_title = 'Follow-Ups - Wrap My Kitchen';

// Function to get lead origin CSS class
function getLeadOriginClass($origin) {
    $origin_lower = strtolower(trim($origin));
    switch ($origin_lower) {
        case 'facebook':
            return 'lead-origin-facebook';
        case 'google':
            return 'lead-origin-google';
        case 'google text':
        case 'googletext':
            return 'lead-origin-googletext';
        case 'referral':
            return 'lead-origin-referral';
        case 'website':
            return 'lead-origin-website';
        case 'instagram':
            return 'lead-origin-instagram';
        case 'tiktok':
            return 'lead-origin-tiktok';
        case 'youtube':
            return 'lead-origin-youtube';
        case 'linkedin':
            return 'lead-origin-linkedin';
        case 'twitter':
            return 'lead-origin-twitter';
        case 'email':
            return 'lead-origin-email';
        case 'phone':
            return 'lead-origin-phone';
        case 'walk-in':
        case 'walkin':
            return 'lead-origin-walkin';
        case 'trade show':
        case 'tradeshow':
            return 'lead-origin-tradeshow';
        case 'whatsapp':
            return 'lead-origin-whatsapp';
        default:
            return 'lead-origin-other';
    }
}

// Handle follow-up date updates
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_followup'])) {
    $lead_id = $_POST['lead_id'];
    $new_followup_date = $_POST['next_followup_date'];
    
    try {
        $stmt = $pdo->prepare("UPDATE leads SET next_followup_date = ? WHERE id = ?");
        $stmt->execute([$new_followup_date, $lead_id]);
        $success_message = "Follow-up date updated successfully!";
    } catch (PDOException $e) {
        $error_message = "Error updating follow-up date: " . $e->getMessage();
    }
}

// Handle payment status updates
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_payment_status'])) {
    $lead_id = $_POST['lead_id'];
    $deposit_paid = isset($_POST['deposit_paid']) ? 1 : 0;
    $balance_paid = isset($_POST['balance_paid']) ? 1 : 0;
    $new_followup_date = $_POST['next_followup_date'] ?? null;
    
    try {
        // First, let's check if the columns exist, if not we'll add them
        $check_columns = $pdo->query("SHOW COLUMNS FROM leads LIKE 'deposit_paid'");
        if ($check_columns->rowCount() == 0) {
            $pdo->exec("ALTER TABLE leads ADD COLUMN deposit_paid TINYINT(1) DEFAULT 0");
            $pdo->exec("ALTER TABLE leads ADD COLUMN balance_paid TINYINT(1) DEFAULT 0");
        }
        
        $stmt = $pdo->prepare("UPDATE leads SET deposit_paid = ?, balance_paid = ?, next_followup_date = ? WHERE id = ?");
        $stmt->execute([$deposit_paid, $balance_paid, $new_followup_date, $lead_id]);
        $success_message = "Payment status updated successfully!";
    } catch (PDOException $e) {
        $error_message = "Error updating payment status: " . $e->getMessage();
    }
}

// Handle lead updates
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_lead'])) {
    $lead_id = $_POST['lead_id'];
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $remarks = $_POST['remarks'];
    $assigned_to = $_POST['assigned_to'];
    $notes = trim($_POST['notes']);
    $project_amount = !empty($_POST['project_amount']) ? floatval($_POST['project_amount']) : 0;
    
    // Handle payment status for sold leads
    $deposit_paid = isset($_POST['deposit_paid']) ? 1 : 0;
    $balance_paid = isset($_POST['balance_paid']) ? 1 : 0;
    
    try {
        // First, let's check if the payment columns exist, if not we'll add them
        $check_columns = $pdo->query("SHOW COLUMNS FROM leads LIKE 'deposit_paid'");
        if ($check_columns->rowCount() == 0) {
            $pdo->exec("ALTER TABLE leads ADD COLUMN deposit_paid TINYINT(1) DEFAULT 0");
            $pdo->exec("ALTER TABLE leads ADD COLUMN balance_paid TINYINT(1) DEFAULT 0");
        }
        
        $stmt = $pdo->prepare("
            UPDATE leads SET 
                name = ?, phone = ?, email = ?, remarks = ?, 
                assigned_to = ?, notes = ?, project_amount = ?,
                deposit_paid = ?, balance_paid = ?
            WHERE id = ?
        ");
        $stmt->execute([$name, $phone, $email, $remarks, $assigned_to, $notes, $project_amount, $deposit_paid, $balance_paid, $lead_id]);
        $success_message = "Lead updated successfully!";
    } catch (PDOException $e) {
        $error_message = "Error updating lead: " . $e->getMessage();
    }
}

// Get leads that need follow-up (overdue and due today)
$today = date('Y-m-d');
$sql = "
    SELECT * FROM leads 
    WHERE next_followup_date <= ? 
    AND remarks NOT IN ('Not Service Area', 'Not Interested', 'Not Compatible')
    ORDER BY next_followup_date ASC, created_at DESC
";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$today]);
    $followup_leads = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_message = "Error fetching follow-up leads: " . $e->getMessage();
    $followup_leads = [];
}

// Get upcoming follow-ups (next 7 days)
$next_week = date('Y-m-d', strtotime('+7 days'));
$upcoming_sql = "
    SELECT * FROM leads 
    WHERE next_followup_date > ? AND next_followup_date <= ?
    AND remarks NOT IN ('Not Service Area', 'Not Interested', 'Not Compatible')
    ORDER BY next_followup_date ASC
";

try {
    $stmt = $pdo->prepare($upcoming_sql);
    $stmt->execute([$today, $next_week]);
    $upcoming_leads = $stmt->fetchAll();
} catch (PDOException $e) {
    $upcoming_leads = [];
}

// Get all users for the assigned_to dropdown
try {
    $stmt = $pdo->prepare("SELECT id, full_name, username FROM users ORDER BY full_name");
    $stmt->execute();
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    $users = [];
}

include 'includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0">
        <i class="fas fa-calendar-check text-primary me-2"></i>
        Follow-Up Management
    </h1>
</div>

<?php if (isset($success_message)): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i>
    <?php echo $success_message; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if (isset($error_message)): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i>
    <?php echo $error_message; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card bg-danger text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Overdue Follow-Ups</h5>
                        <h2 class="mb-0"><?php echo count(array_filter($followup_leads, function($lead) { return $lead['next_followup_date'] < date('Y-m-d'); })); ?></h2>
                    </div>
                    <div class="fs-1 opacity-75">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Due Today</h5>
                        <h2 class="mb-0"><?php echo count(array_filter($followup_leads, function($lead) { return $lead['next_followup_date'] == date('Y-m-d'); })); ?></h2>
                    </div>
                    <div class="fs-1 opacity-75">
                        <i class="fas fa-calendar-day"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Next 7 Days</h5>
                        <h2 class="mb-0"><?php echo count($upcoming_leads); ?></h2>
                    </div>
                    <div class="fs-1 opacity-75">
                        <i class="fas fa-calendar-week"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Priority Follow-Ups -->
<?php if (!empty($followup_leads)): ?>
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-fire text-danger me-2"></i>
            Priority Follow-Ups (Overdue & Due Today)
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Lead Origin</th>
                        <th>Follow-Up Date</th>
                        <th>Status</th>
                        <th>Assigned To</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($followup_leads as $lead): ?>
                    <?php 
                        $is_overdue = $lead['next_followup_date'] < date('Y-m-d');
                        $is_due_today = $lead['next_followup_date'] == date('Y-m-d');
                    ?>
                    <tr class="<?php echo $is_overdue ? 'table-danger' : ($is_due_today ? 'table-warning' : ''); ?>">
                        <td>
                            <strong><?php echo htmlspecialchars($lead['name']); ?></strong>
                            <?php if ($is_overdue): ?>
                                <span class="badge bg-danger ms-2">OVERDUE</span>
                            <?php elseif ($is_due_today): ?>
                                <span class="badge bg-warning">DUE TODAY</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div><?php echo htmlspecialchars($lead['phone']); ?></div>
                            <small class="text-muted"><?php echo htmlspecialchars($lead['email']); ?></small>
                        </td>
                        <td>
                            <span class="badge <?php echo getLeadOriginClass($lead['lead_origin']); ?>"><?php echo htmlspecialchars($lead['lead_origin']); ?></span>
                        </td>
                        <td>
                            <div class="d-flex align-items-center">
                                <span class="me-2"><?php echo date('M j, Y', strtotime($lead['next_followup_date'])); ?></span>
                                <?php if ($is_overdue): ?>
                                    <small class="text-danger">(<?php echo abs((strtotime(date('Y-m-d')) - strtotime($lead['next_followup_date'])) / 86400); ?> days overdue)</small>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <?php if ($lead['remarks'] == 'Sold'): ?>
                                <span class="badge bg-success">Sold</span>
                                <div class="mt-1">
                                    <?php if (isset($lead['deposit_paid']) && $lead['deposit_paid']): ?>
                                        <small class="badge bg-success">Deposit ✓</small>
                                    <?php else: ?>
                                        <small class="badge bg-warning">Deposit Pending</small>
                                    <?php endif; ?>
                                    
                                    <?php if (isset($lead['balance_paid']) && $lead['balance_paid']): ?>
                                        <small class="badge bg-success">Balance ✓</small>
                                    <?php else: ?>
                                        <small class="badge bg-warning">Balance Pending</small>
                                    <?php endif; ?>
                                </div>
                            <?php elseif ($lead['remarks']): ?>
                                <span class="badge bg-secondary"><?php echo htmlspecialchars($lead['remarks']); ?></span>
                            <?php else: ?>
                                <span class="badge bg-light text-dark">New</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($lead['assigned_to']); ?></td>
                        <td>
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#updateFollowupModal<?php echo $lead['id']; ?>">
                                    <i class="fas fa-calendar-alt"></i>
                                </button>
                                <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#editLeadModal<?php echo $lead['id']; ?>">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Upcoming Follow-Ups -->
<?php if (!empty($upcoming_leads)): ?>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-calendar-week text-info me-2"></i>
            Upcoming Follow-Ups (Next 7 Days)
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Lead Origin</th>
                        <th>Follow-Up Date</th>
                        <th>Status</th>
                        <th>Assigned To</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($upcoming_leads as $lead): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($lead['name']); ?></strong></td>
                        <td>
                            <div><?php echo htmlspecialchars($lead['phone']); ?></div>
                            <small class="text-muted"><?php echo htmlspecialchars($lead['email']); ?></small>
                        </td>
                        <td>
                            <span class="badge <?php echo getLeadOriginClass($lead['lead_origin']); ?>"><?php echo htmlspecialchars($lead['lead_origin']); ?></span>
                        </td>
                        <td><?php echo date('M j, Y', strtotime($lead['next_followup_date'])); ?></td>
                        <td>
                            <?php if ($lead['remarks'] == 'Sold'): ?>
                                <span class="badge bg-success">Sold</span>
                                <div class="mt-1">
                                    <?php if (isset($lead['deposit_paid']) && $lead['deposit_paid']): ?>
                                        <small class="badge bg-success">Deposit ✓</small>
                                    <?php else: ?>
                                        <small class="badge bg-warning">Deposit Pending</small>
                                    <?php endif; ?>
                                    
                                    <?php if (isset($lead['balance_paid']) && $lead['balance_paid']): ?>
                                        <small class="badge bg-success">Balance ✓</small>
                                    <?php else: ?>
                                        <small class="badge bg-warning">Balance Pending</small>
                                    <?php endif; ?>
                                </div>
                            <?php elseif ($lead['remarks']): ?>
                                <span class="badge bg-secondary"><?php echo htmlspecialchars($lead['remarks']); ?></span>
                            <?php else: ?>
                                <span class="badge bg-light text-dark">New</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($lead['assigned_to']); ?></td>
                        <td>
                            <div class="btn-group">
                                <?php if ($lead['remarks'] == 'Sold'): ?>
                                    <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#updateFollowupModal<?php echo $lead['id']; ?>" title="Payment Tracking">
                                        <i class="fas fa-dollar-sign"></i>
                                    </button>
                                <?php else: ?>
                                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#updateFollowupModal<?php echo $lead['id']; ?>" title="Update Follow-up">
                                        <i class="fas fa-calendar-alt"></i>
                                    </button>
                                <?php endif; ?>
                                <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#editLeadModal<?php echo $lead['id']; ?>" title="Edit Lead">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Update Follow-up Modals -->
<?php foreach (array_merge($followup_leads, $upcoming_leads) as $lead): ?>
<div class="modal fade" id="updateFollowupModal<?php echo $lead['id']; ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <?php if ($lead['remarks'] == 'Sold'): ?>
                        <i class="fas fa-dollar-sign me-2"></i>Update Payment Status
                    <?php else: ?>
                        <i class="fas fa-calendar-alt me-2"></i>Update Follow-up Date
                    <?php endif; ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            
            <?php if ($lead['remarks'] == 'Sold'): ?>
            <!-- Payment Status Form for Sold Leads -->
            <form method="POST">
                <div class="modal-body">
                    <div class="alert alert-success">
                        <i class="fas fa-trophy me-2"></i>
                        <strong>Sold Lead - Payment Tracking</strong>
                    </div>
                    
                    <p><strong>Client:</strong> <?php echo htmlspecialchars($lead['name']); ?></p>
                    <p><strong>Project Amount:</strong> $<?php echo number_format($lead['project_amount'], 2); ?></p>
                    <p><strong>Current Follow-up Date:</strong> <?php echo date('M j, Y', strtotime($lead['next_followup_date'])); ?></p>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="deposit_paid<?php echo $lead['id']; ?>" 
                                       name="deposit_paid" value="1" <?php echo (isset($lead['deposit_paid']) && $lead['deposit_paid']) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="deposit_paid<?php echo $lead['id']; ?>">
                                    <strong>Deposit Received</strong>
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="balance_paid<?php echo $lead['id']; ?>" 
                                       name="balance_paid" value="1" <?php echo (isset($lead['balance_paid']) && $lead['balance_paid']) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="balance_paid<?php echo $lead['id']; ?>">
                                    <strong>Remaining Balance Received</strong>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="next_followup_date<?php echo $lead['id']; ?>" class="form-label">Next Follow-up Date</label>
                        <input type="date" class="form-control" id="next_followup_date<?php echo $lead['id']; ?>" name="next_followup_date" 
                               value="<?php echo $lead['next_followup_date']; ?>">
                        <div class="form-text">Leave empty if no further follow-up needed</div>
                    </div>
                    
                    <input type="hidden" name="lead_id" value="<?php echo $lead['id']; ?>">
                    <input type="hidden" name="update_payment_status" value="1">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save me-1"></i>Update Payment Status
                    </button>
                </div>
            </form>
            <?php else: ?>
            <!-- Regular Follow-up Form for Non-Sold Leads -->
            <form method="POST">
                <div class="modal-body">
                    <p><strong>Lead:</strong> <?php echo htmlspecialchars($lead['name']); ?></p>
                    <p><strong>Current Follow-up Date:</strong> <?php echo date('M j, Y', strtotime($lead['next_followup_date'])); ?></p>
                    
                    <div class="mb-3">
                        <label for="next_followup_date<?php echo $lead['id']; ?>" class="form-label">New Follow-up Date</label>
                        <input type="date" class="form-control" id="next_followup_date<?php echo $lead['id']; ?>" name="next_followup_date" 
                               value="<?php echo $lead['next_followup_date']; ?>" required>
                    </div>
                    
                    <input type="hidden" name="lead_id" value="<?php echo $lead['id']; ?>">
                    <input type="hidden" name="update_followup" value="1">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Follow-up Date</button>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endforeach; ?>

<!-- Edit Lead Modals -->
<?php foreach (array_merge($followup_leads, $upcoming_leads) as $lead): ?>
<div class="modal fade" id="editLeadModal<?php echo $lead['id']; ?>" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Lead</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="update_lead" value="1">
                    <input type="hidden" name="lead_id" value="<?php echo $lead['id']; ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name<?php echo $lead['id']; ?>" class="form-label">Name *</label>
                            <input type="text" class="form-control" name="name" id="name<?php echo $lead['id']; ?>" value="<?php echo htmlspecialchars($lead['name']); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="phone<?php echo $lead['id']; ?>" class="form-label">Phone *</label>
                            <input type="tel" class="form-control" name="phone" id="phone<?php echo $lead['id']; ?>" value="<?php echo htmlspecialchars($lead['phone']); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="email<?php echo $lead['id']; ?>" class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" id="email<?php echo $lead['id']; ?>" value="<?php echo htmlspecialchars($lead['email']); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="remarks<?php echo $lead['id']; ?>" class="form-label">Status *</label>
                            <select class="form-select" name="remarks" id="remarks<?php echo $lead['id']; ?>" required onchange="togglePaymentTracking<?php echo $lead['id']; ?>(this.value)">
                                <option value="New" <?php echo $lead['remarks'] == 'New' ? 'selected' : ''; ?>>New</option>
                                <option value="Sold" <?php echo $lead['remarks'] == 'Sold' ? 'selected' : ''; ?>>Sold</option>
                                <option value="In Progress" <?php echo $lead['remarks'] == 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
                                <option value="Not Service Area" <?php echo $lead['remarks'] == 'Not Service Area' ? 'selected' : ''; ?>>Not Service Area</option>
                                <option value="Not Interested" <?php echo $lead['remarks'] == 'Not Interested' ? 'selected' : ''; ?>>Not Interested</option>
                                <option value="Not Compatible" <?php echo $lead['remarks'] == 'Not Compatible' ? 'selected' : ''; ?>>Not Compatible</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="assigned_to<?php echo $lead['id']; ?>" class="form-label">Assigned To</label>
                            <select class="form-select" name="assigned_to" id="assigned_to<?php echo $lead['id']; ?>">
                                <option value="">-- Select User --</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo htmlspecialchars($user['full_name']); ?>" 
                                            <?php echo $lead['assigned_to'] == $user['full_name'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($user['full_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="project_amount<?php echo $lead['id']; ?>" class="form-label">Project Amount</label>
                            <input type="number" class="form-control" name="project_amount" id="project_amount<?php echo $lead['id']; ?>" value="<?php echo $lead['project_amount']; ?>" step="0.01" min="0">
                        </div>
                        
                        <!-- Payment Tracking Section - Only visible for Sold leads -->
                        <div class="col-12 mb-3" id="paymentTracking<?php echo $lead['id']; ?>" style="<?php echo $lead['remarks'] == 'Sold' ? '' : 'display: none;'; ?>">
                            <div class="card bg-light border-success">
                                <div class="card-header bg-success text-white">
                                    <h6 class="mb-0">
                                        <i class="fas fa-dollar-sign me-2"></i>Payment Tracking
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox" id="edit_deposit_paid<?php echo $lead['id']; ?>" 
                                                       name="deposit_paid" value="1" <?php echo (isset($lead['deposit_paid']) && $lead['deposit_paid']) ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="edit_deposit_paid<?php echo $lead['id']; ?>">
                                                    <strong>Deposit Received</strong>
                                                    <?php if (isset($lead['deposit_paid']) && $lead['deposit_paid']): ?>
                                                        <span class="badge bg-success ms-2">✓ Paid</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-warning ms-2">Pending</span>
                                                    <?php endif; ?>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox" id="edit_balance_paid<?php echo $lead['id']; ?>" 
                                                       name="balance_paid" value="1" <?php echo (isset($lead['balance_paid']) && $lead['balance_paid']) ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="edit_balance_paid<?php echo $lead['id']; ?>">
                                                    <strong>Remaining Balance Received</strong>
                                                    <?php if (isset($lead['balance_paid']) && $lead['balance_paid']): ?>
                                                        <span class="badge bg-success ms-2">✓ Paid</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-warning ms-2">Pending</span>
                                                    <?php endif; ?>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-2">
                                        <small class="text-muted">
                                            <i class="fas fa-info-circle me-1"></i>
                                            Payment tracking is only available for sold leads. Toggle the switches to mark payments as received.
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 mb-3">
                            <label for="notes<?php echo $lead['id']; ?>" class="form-label">Notes</label>
                            <textarea class="form-control" name="notes" id="notes<?php echo $lead['id']; ?>" rows="3"><?php echo htmlspecialchars($lead['notes']); ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Update Lead</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<script>
// Toggle payment tracking section based on lead status
<?php foreach (array_merge($followup_leads, $upcoming_leads) as $lead): ?>
function togglePaymentTracking<?php echo $lead['id']; ?>(status) {
    const paymentSection = document.getElementById('paymentTracking<?php echo $lead['id']; ?>');
    if (status === 'Sold') {
        paymentSection.style.display = 'block';
    } else {
        paymentSection.style.display = 'none';
        // Reset payment checkboxes when not sold
        document.getElementById('edit_deposit_paid<?php echo $lead['id']; ?>').checked = false;
        document.getElementById('edit_balance_paid<?php echo $lead['id']; ?>').checked = false;
    }
}
<?php endforeach; ?>
</script>

<?php if (empty($followup_leads) && empty($upcoming_leads)): ?>
<div class="text-center py-5">
    <i class="fas fa-calendar-check display-1 text-muted mb-3"></i>
    <h3>All Caught Up!</h3>
    <p class="text-muted">No follow-ups needed at this time. Great job staying on top of your leads!</p>
    <a href="leads.php" class="btn btn-primary">View All Leads</a>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>