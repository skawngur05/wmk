<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$page_title = 'All Leads - Wrap My Kitchen';

// Function to get lead origin CSS class
function getLeadOriginClass($origin) {
    $origin_lower = strtolower(trim($origin));
    switch ($origin_lower) {
        case 'facebook':
            return 'lead-origin-facebook';
        case 'google':
            return 'lead-origin-google';
        case 'google text':
        case 'googletext':
            return 'lead-origin-googletext';
        case 'referral':
            return 'lead-origin-referral';
        case 'website':
            return 'lead-origin-website';
        case 'instagram':
            return 'lead-origin-instagram';
        case 'tiktok':
            return 'lead-origin-tiktok';
        case 'youtube':
            return 'lead-origin-youtube';
        case 'linkedin':
            return 'lead-origin-linkedin';
        case 'twitter':
            return 'lead-origin-twitter';
        case 'email':
            return 'lead-origin-email';
        case 'phone':
            return 'lead-origin-phone';
        case 'walk-in':
        case 'walkin':
            return 'lead-origin-walkin';
        case 'trade show':
        case 'tradeshow':
            return 'lead-origin-tradeshow';
        case 'whatsapp':
            return 'lead-origin-whatsapp';
        default:
            return 'lead-origin-other';
    }
}

// Handle search and filters
$search = $_GET['search'] ?? '';
$origin_filter = $_GET['origin'] ?? '';
$status_filter = $_GET['status'] ?? '';
$assigned_filter = $_GET['assigned'] ?? '';

// Build query
$where_conditions = [];
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(name LIKE ? OR phone LIKE ? OR email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($origin_filter)) {
    $where_conditions[] = "lead_origin = ?";
    $params[] = $origin_filter;
}

if (!empty($status_filter)) {
    $where_conditions[] = "remarks = ?";
    $params[] = $status_filter;
}

if (!empty($assigned_filter)) {
    $where_conditions[] = "assigned_to = ?";
    $params[] = $assigned_filter;
}

$where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";
$sql = "SELECT * FROM leads $where_clause ORDER BY date_created DESC, next_followup_date ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$leads = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1><i class="fas fa-users me-2"></i>All Leads</h1>
            <a href="add_lead.php" class="btn btn-primary">
                <i class="fas fa-plus me-2"></i>Add New Lead
            </a>
        </div>
    </div>
</div>

<!-- Search and Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label for="search" class="form-label">Search</label>
                <input type="text" class="form-control" id="search" name="search" 
                       placeholder="Name, phone, email..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-2">
                <label for="origin" class="form-label">Origin</label>
                <select class="form-select" id="origin" name="origin">
                    <option value="">All Origins</option>
                    <option value="Facebook" <?php echo $origin_filter === 'Facebook' ? 'selected' : ''; ?>>Facebook</option>
                    <option value="Google Text" <?php echo $origin_filter === 'Google Text' ? 'selected' : ''; ?>>Google Text</option>
                    <option value="Instagram" <?php echo $origin_filter === 'Instagram' ? 'selected' : ''; ?>>Instagram</option>
                    <option value="Trade Show" <?php echo $origin_filter === 'Trade Show' ? 'selected' : ''; ?>>Trade Show</option>
                    <option value="WhatsApp" <?php echo $origin_filter === 'WhatsApp' ? 'selected' : ''; ?>>WhatsApp</option>
                    <option value="Commercial" <?php echo $origin_filter === 'Commercial' ? 'selected' : ''; ?>>Commercial</option>
                    <option value="Referral" <?php echo $origin_filter === 'Referral' ? 'selected' : ''; ?>>Referral</option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="">All Statuses</option>
                    <option value="New" <?php echo $status_filter === 'New' ? 'selected' : ''; ?>>New</option>
                    <option value="In Progress" <?php echo $status_filter === 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
                    <option value="Sold" <?php echo $status_filter === 'Sold' ? 'selected' : ''; ?>>Sold</option>
                    <option value="Not Interested" <?php echo $status_filter === 'Not Interested' ? 'selected' : ''; ?>>Not Interested</option>
                    <option value="Not Service Area" <?php echo $status_filter === 'Not Service Area' ? 'selected' : ''; ?>>Not Service Area</option>
                    <option value="Not Compatible" <?php echo $status_filter === 'Not Compatible' ? 'selected' : ''; ?>>Not Compatible</option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="assigned" class="form-label">Assigned To</label>
                <select class="form-select" id="assigned" name="assigned">
                    <option value="">All Assignees</option>
                    <option value="Kim" <?php echo $assigned_filter === 'Kim' ? 'selected' : ''; ?>>Kim</option>
                    <option value="Patrick" <?php echo $assigned_filter === 'Patrick' ? 'selected' : ''; ?>>Patrick</option>
                    <option value="Lina" <?php echo $assigned_filter === 'Lina' ? 'selected' : ''; ?>>Lina</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">&nbsp;</label>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search me-1"></i>Filter
                    </button>
                    <a href="leads.php" class="btn btn-outline-secondary">
                        <i class="fas fa-times me-1"></i>Clear
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Results -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-list me-2"></i>Leads 
            <span class="badge bg-primary"><?php echo count($leads); ?></span>
        </h5>
    </div>
    <div class="card-body p-0">
        <?php if (empty($leads)): ?>
            <div class="text-center py-5">
                <i class="fas fa-search fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">No leads found</h5>
                <p class="text-muted">Try adjusting your search criteria or <a href="add_lead.php">add a new lead</a>.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Date</th>
                            <th>Name</th>
                            <th>Contact</th>
                            <th>Origin</th>
                            <th>Next Follow-up</th>
                            <th>Assigned To</th>
                            <th>Status</th>
                            <th>Amount</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($leads as $lead): ?>
                        <tr>
                            <td>
                                <small><?php echo date('M j, Y', strtotime($lead['date_created'])); ?></small>
                            </td>
                            <td>
                                <strong><?php echo htmlspecialchars($lead['name']); ?></strong>
                                <?php if ($lead['notes']): ?>
                                    <i class="fas fa-comment-dots text-muted ms-1" 
                                       title="<?php echo htmlspecialchars($lead['notes']); ?>"></i>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($lead['phone']): ?>
                                    <div><i class="fas fa-phone text-muted me-1"></i><?php echo htmlspecialchars($lead['phone']); ?></div>
                                <?php endif; ?>
                                <?php if ($lead['email']): ?>
                                    <div><i class="fas fa-envelope text-muted me-1"></i><small><?php echo htmlspecialchars($lead['email']); ?></small></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo getLeadOriginClass($lead['lead_origin']); ?>"><?php echo htmlspecialchars($lead['lead_origin']); ?></span>
                            </td>
                            <td>
                                <?php if ($lead['next_followup_date']): ?>
                                    <?php
                                    $followup_date = strtotime($lead['next_followup_date']);
                                    $today = strtotime(date('Y-m-d'));
                                    $class = '';
                                    if ($followup_date < $today) {
                                        $class = 'text-danger';
                                    } elseif ($followup_date == $today) {
                                        $class = 'text-warning';
                                    }
                                    ?>
                                    <span class="<?php echo $class; ?>">
                                        <?php echo date('M j, Y', $followup_date); ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">Not set</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-secondary"><?php echo htmlspecialchars($lead['assigned_to']); ?></span>
                            </td>
                            <td>
                                <?php
                                $status_class = match($lead['remarks']) {
                                    'Sold' => 'success',
                                    'Not Interested' => 'danger',
                                    'Not Service Area' => 'warning',
                                    'Not Compatible' => 'secondary',
                                    'In Progress' => 'info',
                                    default => 'primary'
                                };
                                ?>
                                <span class="badge bg-<?php echo $status_class; ?>">
                                    <?php echo htmlspecialchars($lead['remarks']); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($lead['project_amount'] > 0): ?>
                                    <strong>$<?php echo number_format($lead['project_amount'], 2); ?></strong>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary" title="Edit" 
                                        onclick="openEditModal(<?php echo $lead['id']; ?>)">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Edit Lead Modal -->
<div class="modal fade" id="editLeadModal" tabindex="-1" aria-labelledby="editLeadModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editLeadModalLabel">
                    <i class="fas fa-edit me-2"></i>Edit Lead
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="modalLoadingSpinner" class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2 text-muted">Loading lead information...</p>
                </div>
                
                <form id="editLeadForm" style="display: none;">
                    <input type="hidden" id="leadId" name="id">
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="editName" class="form-label">Client Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="editName" name="name" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editPhone" class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" id="editPhone" name="phone">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="editEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" id="editEmail" name="email">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editLeadOrigin" class="form-label">Lead Origin <span class="text-danger">*</span></label>
                            <select class="form-select" id="editLeadOrigin" name="lead_origin" required>
                                <option value="">Select Origin</option>
                                <option value="Facebook">Facebook</option>
                                <option value="Google Text">Google Text</option>
                                <option value="Instagram">Instagram</option>
                                <option value="Trade Show">Trade Show</option>
                                <option value="WhatsApp">WhatsApp</option>
                                <option value="Commercial">Commercial</option>
                                <option value="Referral">Referral</option>
                                <option value="Website">Website</option>
                                <option value="Google">Google</option>
                                <option value="Phone">Phone</option>
                                <option value="Email">Email</option>
                                <option value="Walk-in">Walk-in</option>
                                <option value="TikTok">TikTok</option>
                                <option value="YouTube">YouTube</option>
                                <option value="LinkedIn">LinkedIn</option>
                                <option value="Twitter">Twitter</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="editNextFollowup" class="form-label">Next Follow-up Date</label>
                            <input type="date" class="form-control" id="editNextFollowup" name="next_followup_date">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editRemarks" class="form-label">Status</label>
                            <select class="form-select" id="editRemarks" name="remarks">
                                <option value="New">New</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Sold">Sold</option>
                                <option value="Not Interested">Not Interested</option>
                                <option value="Not Service Area">Not Service Area</option>
                                <option value="Not Compatible">Not Compatible</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="editAssignedTo" class="form-label">Assigned To</label>
                            <select class="form-select" id="editAssignedTo" name="assigned_to">
                                <option value="Kim">Kim</option>
                                <option value="Patrick">Patrick</option>
                                <option value="Lina">Lina</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editProjectAmount" class="form-label">Project Amount</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" class="form-control" id="editProjectAmount" name="project_amount" 
                                       step="0.01" min="0" placeholder="0.00">
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="editNotes" class="form-label">Notes</label>
                        <textarea class="form-control" id="editNotes" name="notes" rows="3"></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="editAdditionalNotes" class="form-label">Additional Notes</label>
                        <textarea class="form-control" id="editAdditionalNotes" name="additional_notes" rows="2"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="fas fa-times me-1"></i>Cancel
                </button>
                <button type="button" class="btn btn-primary" id="saveLeadBtn" onclick="saveLead()" style="display: none;">
                    <i class="fas fa-save me-1"></i>Save Changes
                </button>
            </div>
        </div>
    </div>
</div>

<script>
let editModal;

document.addEventListener('DOMContentLoaded', function() {
    editModal = new bootstrap.Modal(document.getElementById('editLeadModal'));
});

function openEditModal(leadId) {
    // Show modal and loading spinner
    document.getElementById('modalLoadingSpinner').style.display = 'block';
    document.getElementById('editLeadForm').style.display = 'none';
    document.getElementById('saveLeadBtn').style.display = 'none';
    editModal.show();
    
    // Fetch lead data
    fetch('handlers/get_lead.php?id=' + leadId)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                populateEditForm(data.lead);
                document.getElementById('modalLoadingSpinner').style.display = 'none';
                document.getElementById('editLeadForm').style.display = 'block';
                document.getElementById('saveLeadBtn').style.display = 'inline-block';
            } else {
                alert('Error loading lead data: ' + data.message);
                editModal.hide();
            }
        })
        .catch(error => {
            alert('Error: ' + error);
            editModal.hide();
        });
}

function populateEditForm(lead) {
    document.getElementById('leadId').value = lead.id;
    document.getElementById('editName').value = lead.name || '';
    document.getElementById('editPhone').value = lead.phone || '';
    document.getElementById('editEmail').value = lead.email || '';
    document.getElementById('editLeadOrigin').value = lead.lead_origin || '';
    document.getElementById('editNextFollowup').value = lead.next_followup_date || '';
    document.getElementById('editRemarks').value = lead.remarks || 'New';
    document.getElementById('editAssignedTo').value = lead.assigned_to || '';
    document.getElementById('editProjectAmount').value = lead.project_amount || '';
    document.getElementById('editNotes').value = lead.notes || '';
    document.getElementById('editAdditionalNotes').value = lead.additional_notes || '';
}

function saveLead() {
    const form = document.getElementById('editLeadForm');
    const formData = new FormData(form);
    
    // Disable save button and show loading
    const saveBtn = document.getElementById('saveLeadBtn');
    const originalText = saveBtn.innerHTML;
    saveBtn.disabled = true;
    saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Saving...';
    
    fetch('handlers/update_lead.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Show success message
            const alert = document.createElement('div');
            alert.className = 'alert alert-success alert-dismissible fade show';
            alert.innerHTML = `
                <i class="fas fa-check-circle me-2"></i>Lead updated successfully!
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            // Insert alert at the top of the page content
            const firstRow = document.querySelector('.row');
            if (firstRow && firstRow.parentNode) {
                firstRow.parentNode.insertBefore(alert, firstRow);
            }
            
            // Close modal and reload page to show updated data
            editModal.hide();
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } else {
            alert('Error updating lead: ' + data.message);
        }
    })
    .catch(error => {
        alert('Error: ' + error);
    })
    .finally(() => {
        // Re-enable save button
        saveBtn.disabled = false;
        saveBtn.innerHTML = originalText;
    });
}
</script>

<?php include 'includes/footer.php'; ?>
