<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$page_title = 'Dashboard - Wrap My Kitchen';

// Function to get lead origin CSS class
function getLeadOriginClass($origin) {
    $origin_lower = strtolower(trim($origin));
    switch ($origin_lower) {
        case 'facebook':
            return 'lead-origin-facebook';
        case 'google':
            return 'lead-origin-google';
        case 'google text':
        case 'googletext':
            return 'lead-origin-googletext';
        case 'referral':
            return 'lead-origin-referral';
        case 'website':
            return 'lead-origin-website';
        case 'instagram':
            return 'lead-origin-instagram';
        case 'tiktok':
            return 'lead-origin-tiktok';
        case 'youtube':
            return 'lead-origin-youtube';
        case 'linkedin':
            return 'lead-origin-linkedin';
        case 'twitter':
            return 'lead-origin-twitter';
        case 'email':
            return 'lead-origin-email';
        case 'phone':
            return 'lead-origin-phone';
        case 'walk-in':
        case 'walkin':
            return 'lead-origin-walkin';
        case 'trade show':
        case 'tradeshow':
            return 'lead-origin-tradeshow';
        case 'whatsapp':
            return 'lead-origin-whatsapp';
        default:
            return 'lead-origin-other';
    }
}

// Get today's follow-ups
$today = date('Y-m-d');
$stmt = $pdo->prepare("SELECT * FROM leads WHERE next_followup_date = ? ORDER BY name");
$stmt->execute([$today]);
$todays_followups = $stmt->fetchAll();

// Get overdue follow-ups
$stmt = $pdo->prepare("SELECT * FROM leads WHERE next_followup_date < ? AND remarks NOT IN ('Sold', 'Not Interested') ORDER BY next_followup_date");
$stmt->execute([$today]);
$overdue_followups = $stmt->fetchAll();

// Get recent leads (last 7 days)
$week_ago = date('Y-m-d', strtotime('-7 days'));
$stmt = $pdo->prepare("SELECT * FROM leads WHERE date_created >= ? ORDER BY date_created DESC LIMIT 10");
$stmt->execute([$week_ago]);
$recent_leads = $stmt->fetchAll();

// Get quick stats
$stmt = $pdo->query("SELECT COUNT(*) as total FROM leads");
$total_leads = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM leads WHERE remarks = 'Sold'");
$total_sold = $stmt->fetch()['total'];

$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM leads WHERE date_created = ?");
$stmt->execute([$today]);
$todays_leads = $stmt->fetch()['total'];

include 'includes/header.php';
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1><i class="fas fa-tachometer-alt me-2"></i>Dashboard</h1>
            <div class="text-muted">
                Welcome back, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!
            </div>
        </div>
    </div>
</div>

<!-- Quick Stats -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo $total_leads; ?></h4>
                        <p class="mb-0">Total Leads</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-users fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo $total_sold; ?></h4>
                        <p class="mb-0">Sold</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-handshake fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo count($todays_followups); ?></h4>
                        <p class="mb-0">Today's Follow-ups</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-calendar-day fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo $todays_leads; ?></h4>
                        <p class="mb-0">New Today</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-plus fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Today's Follow-ups -->
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-calendar-day me-2"></i>Today's Follow-ups</h5>
            </div>
            <div class="card-body p-0">
                <?php if (empty($todays_followups)): ?>
                    <div class="text-center py-4 text-muted">
                        <i class="fas fa-calendar-check fa-3x mb-3"></i>
                        <p>No follow-ups scheduled for today!</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Assigned To</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($todays_followups as $lead): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($lead['name']); ?></strong>
                                        <br><small class="text-muted"><?php echo htmlspecialchars($lead['lead_origin']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($lead['phone']); ?></td>
                                    <td>
                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($lead['assigned_to']); ?></span>
                                    </td>
                                    <td>
                                        <a href="edit_lead.php?id=<?php echo $lead['id']; ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Overdue Follow-ups -->
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i>Overdue Follow-ups</h5>
            </div>
            <div class="card-body p-0">
                <?php if (empty($overdue_followups)): ?>
                    <div class="text-center py-4 text-muted">
                        <i class="fas fa-check-circle fa-3x mb-3"></i>
                        <p>No overdue follow-ups!</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Name</th>
                                    <th>Due Date</th>
                                    <th>Assigned To</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($overdue_followups as $lead): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($lead['name']); ?></strong>
                                        <br><small class="text-muted"><?php echo htmlspecialchars($lead['lead_origin']); ?></small>
                                    </td>
                                    <td>
                                        <span class="text-danger">
                                            <?php echo date('M j, Y', strtotime($lead['next_followup_date'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($lead['assigned_to']); ?></span>
                                    </td>
                                    <td>
                                        <a href="edit_lead.php?id=<?php echo $lead['id']; ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Recent Leads -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-clock me-2"></i>Recent Leads (Last 7 days)</h5>
            </div>
            <div class="card-body p-0">
                <?php if (empty($recent_leads)): ?>
                    <div class="text-center py-4 text-muted">
                        <i class="fas fa-inbox fa-3x mb-3"></i>
                        <p>No recent leads found.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Date</th>
                                    <th>Name</th>
                                    <th>Origin</th>
                                    <th>Phone</th>
                                    <th>Assigned To</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_leads as $lead): ?>
                                <tr>
                                    <td><?php echo date('M j', strtotime($lead['date_created'])); ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($lead['name']); ?></strong>
                                        <?php if ($lead['email']): ?>
                                            <br><small class="text-muted"><?php echo htmlspecialchars($lead['email']); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo getLeadOriginClass($lead['lead_origin']); ?>"><?php echo htmlspecialchars($lead['lead_origin']); ?></span>
                                    </td>
                                    <td><?php echo htmlspecialchars($lead['phone']); ?></td>
                                    <td>
                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($lead['assigned_to']); ?></span>
                                    </td>
                                    <td>
                                        <?php if ($lead['project_amount'] > 0): ?>
                                            $<?php echo number_format($lead['project_amount'], 2); ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        $status_class = match($lead['remarks']) {
                                            'Sold' => 'success',
                                            'Not Interested' => 'danger',
                                            'Not Service Area' => 'warning',
                                            'Not Compatible' => 'secondary',
                                            'In Progress' => 'info',
                                            default => 'primary'
                                        };
                                        ?>
                                        <span class="badge bg-<?php echo $status_class; ?>">
                                            <?php echo htmlspecialchars($lead['remarks']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="edit_lead.php?id=<?php echo $lead['id']; ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
