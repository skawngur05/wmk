<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

requireAuth();

header('Content-Type: application/json');

if ($_POST && isset($_POST['lead_id'], $_POST['field'], $_POST['value'])) {
    $lead_id = (int)$_POST['lead_id'];
    $field = $_POST['field'];
    $value = $_POST['value'];
    
    // Whitelist allowed fields for security
    $allowed_fields = [
        'remarks', 'next_followup_date', 'assigned_to', 'notes', 
        'additional_notes', 'project_amount'
    ];
    
    if (!in_array($field, $allowed_fields)) {
        echo json_encode(['success' => false, 'error' => 'Invalid field']);
        exit();
    }
    
    try {
        $sql = "UPDATE leads SET $field = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$value, $lead_id]);
        
        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Missing required parameters']);
}
?>
